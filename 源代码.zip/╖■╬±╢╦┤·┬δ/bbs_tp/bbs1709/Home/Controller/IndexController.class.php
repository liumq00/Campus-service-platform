<?php
namespace Home\Controller;
use Think\Controller;
header("Access-Control-Allow-Origin:*");
header("Access-Control-Allow-Methods:GET, POST, OPTIONS, DELETE");
header("Access-Control-Allow-Headers:DNT,X-Mx-ReqToken,Keep-Alive,User-Agent,X-Requested-With,If-Modified-Since,Cache-Control,Content-Type, Accept-Language, Origin, Accept-Encoding");

class IndexController extends Controller {
    public function index(){

        //品类列表
        $type=M('type');
        $res1 = $type->where('pid=0')->select();
        $res2 = $type->where('pid!=0')->select();
//        var_dump($res2);

        //网站配置
//        $config = M('config');
//        $configRes = $config->select()[0];

        //把获取网站配置写到基类中，然后调用
        Controller::getConfig();

        //友情链接
        $link = M('friendlink');
        $linkRes = $link->select();

        //压入数据
        $this->assign('res1',$res1);
        $this->assign('res2',$res2);
//        $this->assign('configRes',$configRes);
        $this->assign('linkRes',$linkRes);

        //解析模板
        $this->display('Index/index');
    }
    function initial(){
           $result = [
                'status' =>'success',
                 'sessionid'=>'0',
            ];
        exit(json_encode($result));
    }

//   帖子接口

    function getAllPost(){
        //返还的json数据
        function show($status,$msg,$data=[],$count){
            $result = [
                'status' => $status,
                'msg' => $msg,
                'data' => $data,
                'count'=>$count,
            ];
            exit(json_encode($result));
        }
//        $type=M('type');
//        $fatype = $type->where('pid=0')->select();
//
//        //获取post表的类别id
//        $tid=I('get.tid');
//        //获取一二级主题
//        $type=M('type');
//        $son=$type->field('id,name,pid')->find($tid);
//        $father=$type->field('name')->where('id='.$son['pid'])->find();
//
//
//

        //获取请求的类别type
        $order=I('get.order');
        $post=M('post');
        $reply=M('reply');
        if($order=='default'){

            $res2=$post->query('select post.pic, post.pic2, (select count(id) from reply where reply.pid = post.id) as reviewsCount, user.userName,post.title,post.content,post.count,type.name,post.id,post.ctime,userdetail.photo,userdetail.nickName,post.elite from post left join user on user.id=post.uid left join userdetail on user.id=userdetail.uid left join type on type.id=post.tid  where post.recycle!=1&&type.pid=17');
            return  show( 'success','获取默认帖子成功',$res2);
        }else if($order=='mostnew'){

            $res2=$post->query('select post.pic, post.pic2, (select count(id) from reply where reply.pid = post.id) as reviewsCount, user.userName,post.title,post.content,post.count,type.name,post.id,post.ctime,userdetail.photo,userdetail.nickName,post.elite from post left join user on user.id=post.uid left join userdetail on user.id=userdetail.uid left join type on type.id=post.tid where post.recycle!=1&&type.pid=17 ORDER BY post.ctime DESC ');
            return  show( 'success','获取最新帖子成功',$res2);
        }else if($order=='mosthot'){

            $res2=$post->query('select post.pic, post.pic2, (select count(id) from reply where reply.pid = post.id) as reviewsCount, user.userName,post.title,post.content,post.count,type.name,post.id,post.ctime,userdetail.photo,userdetail.nickName,post.elite from post left join user on user.id=post.uid left join userdetail on user.id=userdetail.uid left join type on type.id=post.tid where post.recycle!=1&&type.pid=17 ORDER BY post.count DESC ');
            return  show('success','获取最热帖子成功',$res2);
        } else if($order=='学术交流'){

            //实例化，并查询帖子标题 内容以及发帖人用户名
            $res2=$post->query('select post.pic, post.pic2, (select count(id) from reply where reply.pid = post.id) as reviewsCount, user.userName,post.title,post.content,post.count,type.name,post.id,post.ctime,userdetail.photo,userdetail.nickName,post.elite from post left join user on user.id=post.uid left join userdetail on user.id=userdetail.uid left join type on type.id=post.tid where post.recycle!=1&&post.tid=23');
            return  show('success','获取帖子成功',$res2);
        }else if($order=='校园淘宝'){
            //实例化，并查询帖子标题 内容以及发帖人用户名
            $res2=$post->query('select post.pic, post.pic2, (select count(id) from reply where reply.pid = post.id) as reviewsCount, user.userName,post.title,post.content,post.count,type.name,post.id,post.ctime,userdetail.photo,userdetail.nickName,post.elite from post left join user on user.id=post.uid left join userdetail on user.id=userdetail.uid left join type on type.id=post.tid where post.recycle!=1&&post.tid=26');
            return  show('success','获取帖子成功',$res2);
        }else if($order=='兼职招聘'){
            //实例化，并查询帖子标题 内容以及发帖人用户名
            $res2=$post->query('select post.pic, post.pic2, (select count(id) from reply where reply.pid = post.id) as reviewsCount, user.userName,post.title,post.content,post.count,type.name,post.id,post.ctime,userdetail.photo,userdetail.nickName,post.elite from post left join user on user.id=post.uid left join userdetail on user.id=userdetail.uid left join type on type.id=post.tid where post.recycle!=1&&post.tid=27');
            return  show('success','获取帖子成功',$res2);
        }else if($order=='摄影'){

            //实例化，并查询帖子标题 内容以及发帖人用户名
            $res2=$post->query('select post.pic, post.pic2, (select count(id) from reply where reply.pid = post.id) as reviewsCount, user.userName,post.title,post.content,post.count,type.name,post.id,post.ctime,userdetail.photo,userdetail.nickName,post.elite from post left join user on user.id=post.uid left join userdetail on user.id=userdetail.uid left join type on type.id=post.tid where post.recycle!=1&&post.tid=28');
            return  show('success','获取帖子成功',$res2);
        }else if($order=='社团'){

            //实例化，并查询帖子标题 内容以及发帖人用户名
            $res2=$post->query('select post.pic, post.pic2, (select count(id) from reply where reply.pid = post.id) as reviewsCount, user.userName,post.title,post.content,post.count,type.name,post.id,post.ctime,userdetail.photo,userdetail.nickName,post.elite from post left join user on user.id=post.uid left join userdetail on user.id=userdetail.uid left join type on type.id=post.tid where post.recycle!=1&&post.tid=29');
            return  show('success','获取帖子成功',$res2);
        }else if($order=='娱乐杂谈'){

            //实例化，并查询帖子标题 内容以及发帖人用户名
            $res2=$post->query('select post.pic, post.pic2, (select count(id) from reply where reply.pid = post.id) as reviewsCount, user.userName,post.title,post.content,post.count,type.name,post.id,post.ctime,userdetail.photo,userdetail.nickName,post.elite from post left join user on user.id=post.uid left join userdetail on user.id=userdetail.uid left join type on type.id=post.tid where post.recycle!=1&&post.tid=30');
            return  show('success','获取帖子成功',$res2);
        }else if($order=='非诚勿扰'){

            //实例化，并查询帖子标题 内容以及发帖人用户名
            $res2=$post->query('select post.pic, post.pic2, (select count(id) from reply where reply.pid = post.id) as reviewsCount, user.userName,post.title,post.content,post.count,type.name,post.id,post.ctime,userdetail.photo,userdetail.nickName,post.elite from post left join user on user.id=post.uid left join userdetail on user.id=userdetail.uid left join type on type.id=post.tid where post.recycle!=1&&post.tid=31');
            return  show('success','获取帖子成功',$res2);
        }else if($order=='吐槽'){

            //实例化，并查询帖子标题 内容以及发帖人用户名
            $res2=$post->query('select post.pic, post.pic2, (select count(id) from reply where reply.pid = post.id) as reviewsCount, user.userName,post.title,post.content,post.count,type.name,post.id,post.ctime,userdetail.photo,userdetail.nickName,post.elite from post left join user on user.id=post.uid left join userdetail on user.id=userdetail.uid left join type on type.id=post.tid where post.recycle!=1&&post.tid=32');
            return  show('success','获取帖子成功',$res2);
        }else if($order=='privage'){
            $userName=$_GET['username'];
            //实例化，并查询帖子标题 内容以及发帖人用户名
            $res2=$post->query('select post.pic, post.pic2, (select count(id) from reply where reply.pid = post.id) as reviewsCount, user.userName,post.title,post.content,post.count,type.name,post.id,post.ctime,userdetail.photo,userdetail.nickName,post.elite from post left join user on user.id=post.uid left join userdetail on user.id=userdetail.uid left join type on type.id=post.tid where post.recycle!=1&&user.userName="'.$userName.'" ');
            return  show('success','获取帖子成功',$res2);
        }

    }
//发帖
    function doPost(){
        //返还的json数据
        function show($status,$msg,$data=[],$count){
            $result = [
                'status' => $status,
                'msg' => $msg,
                'data' => $data,
                'count'=>$count,
            ];
            exit(json_encode($result));
        }
        $post=M('post');

        //获取用户数据
        $uid = I('get.uid');
        $title = I('get.title');
        $content = I('get.content');
        $ctime = I('get.ctime');
        $tid = I('get.tid');
        $pic = I('get.pic');

        //执行修改
        $res= $post->add($_GET);
        //判断结果
        if($res){
           return show('success',$_GET);
        }else{
            return show('defeat',$_GET);
        }
    }
//    更新热度
    function hot(){

        $post=M('post');

        $id=I('get.id');

        $count=$post->field(count)->where('post.id="'.$id.'"')->find();
        $count["count"]++;
        //4. 记录查看次数
        $post->where('id = "'.$id.'"')->save( $count);


    }
    //获取评论
    function  getReply(){
        function show($status,$msg,$data=[],$count){
            $result = [
                'status' => $status,
                'msg' => $msg,
                'data' => $data,
                'count'=>$count,
            ];
            exit(json_encode($result));
        }
        //获取回帖信息，以及回帖人信息
        $id=I('get.id');
        $reply=M('reply');
        $replyRes=$reply->where('pid='.$id)->select();

        foreach ($replyRes as $k=>$v){
            $ud=M('userdetail');
            $replyRes[$k]['nickName']=$ud->where('uid='.$v['uid'])->field('nickName')->find()['nickname'];
            $replyRes[$k]['photo']=$ud->where('uid='.$v['uid'])->field('photo')->find()['photo'];
        }
        return show('success' ,'回帖信息',$replyRes);

    }
    //    //发布评论
    function doReply(){
        function show($status,$msg,$data=[],$count){
            $result = [
                'status' => $status,
                'msg' => $msg,
                'data' => $data,
                'count'=>$count,
            ];
            exit(json_encode($result));
        }
        // 获取信息，并添加到reply表格
        $reply=M('reply');
        if($res = $reply->add($_GET)){
            return show('success','评论成功');
        }


    }
//    functionGET
    //新闻接口
    function getAllNews(){
            //返还的json数据
        function show($status,$msg,$data=[],$count){
            $result = [
                'status' => $status,
                'msg' => $msg,
                'data' => $data,
                'count'=>$count,
            ];
            exit(json_encode($result));
        }
//
        //获取请求的类别type
        $content=I('get.content');
        $post=M('post');
        $reply=M('reply');
        if($content=='recommend'){

            $res2=$post->query('select post.pic, post.pic2, (select count(id) from reply where reply.pid = post.id) as reviewsCount, user.userName,post.title,post.content,post.count,type.name,post.id,post.ctime,userdetail.photo,userdetail.nickName,post.elite from post left join user on user.id=post.uid left join userdetail on user.id=userdetail.uid left join type on type.id=post.tid  where post.recycle!=1&&type.pid=1 ORDER BY post.count DESC ');
            return  show( 'success','获取默认帖子成功',$res2);

        } else if($content=='inform'){

            //实例化，并查询帖子标题 内容以及发帖人用户名
            $res2=$post->query('select post.pic, post.pic2, (select count(id) from reply where reply.pid = post.id) as reviewsCount, user.userName,post.title,post.content,post.count,type.name,post.id,post.ctime,userdetail.photo,userdetail.nickName,post.elite from post left join user on user.id=post.uid left join userdetail on user.id=userdetail.uid left join type on type.id=post.tid where post.recycle!=1&&post.tid=10');
            return  show('success','获取帖子成功',$res2);
        }else if($content=='activity'){
            //实例化，并查询帖子标题 内容以及发帖人用户名
            $res2=$post->query('select post.pic, post.pic2, (select count(id) from reply where reply.pid = post.id) as reviewsCount, user.userName,post.title,post.content,post.count,type.name,post.id,post.ctime,userdetail.photo,userdetail.nickName,post.elite from post left join user on user.id=post.uid left join userdetail on user.id=userdetail.uid left join type on type.id=post.tid where post.recycle!=1&&post.tid=5');
            return  show('success','获取帖子成功',$res2);
        }else if($content=='learn'){
            //实例化，并查询帖子标题 内容以及发帖人用户名
            $res2=$post->query('select post.pic, post.pic2, (select count(id) from reply where reply.pid = post.id) as reviewsCount, user.userName,post.title,post.content,post.count,type.name,post.id,post.ctime,userdetail.photo,userdetail.nickName,post.elite from post left join user on user.id=post.uid left join userdetail on user.id=userdetail.uid left join type on type.id=post.tid where post.recycle!=1&&post.tid=6');
            return  show('success','获取帖子成功',$res2);
        }else if($content=='race'){

            //实例化，并查询帖子标题 内容以及发帖人用户名
            $res2=$post->query('select post.pic, post.pic2, (select count(id) from reply where reply.pid = post.id) as reviewsCount, user.userName,post.title,post.content,post.count,type.name,post.id,post.ctime,userdetail.photo,userdetail.nickName,post.elite from post left join user on user.id=post.uid left join userdetail on user.id=userdetail.uid left join type on type.id=post.tid where post.recycle!=1&&post.tid=7');
            return  show('success','获取帖子成功',$res2);
        }else if($content=='mircroom'){

            //实例化，并查询帖子标题 内容以及发帖人用户名
            $res2=$post->query('select post.pic, post.pic2, (select count(id) from reply where reply.pid = post.id) as reviewsCount, user.userName,post.title,post.content,post.count,type.name,post.id,post.ctime,userdetail.photo,userdetail.nickName,post.elite from post left join user on user.id=post.uid left join userdetail on user.id=userdetail.uid left join type on type.id=post.tid where post.recycle!=1&&post.tid=8');
            return  show('success','获取帖子成功',$res2);
        }else if($content=='job'){

            //实例化，并查询帖子标题 内容以及发帖人用户名
            $res2=$post->query('select post.pic, post.pic2, (select count(id) from reply where reply.pid = post.id) as reviewsCount, user.userName,post.title,post.content,post.count,type.name,post.id,post.ctime,userdetail.photo,userdetail.nickName,post.elite from post left join user on user.id=post.uid left join userdetail on user.id=userdetail.uid left join type on type.id=post.tid where post.recycle!=1&&post.tid=25');
            return  show('success','获取帖子成功',$res2);
        }else if($content=='mirclife'){

            //实例化，并查询帖子标题 内容以及发帖人用户名
            $res2=$post->query('select post.pic, post.pic2, (select count(id) from reply where reply.pid = post.id) as reviewsCount, user.userName,post.title,post.content,post.count,type.name,post.id,post.ctime,userdetail.photo,userdetail.nickName,post.elite from post left join user on user.id=post.uid left join userdetail on user.id=userdetail.uid left join type on type.id=post.tid where post.recycle!=1&&post.tid=24');
            return  show('success','获取帖子成功',$res2);
        }
    }

    //获取文章
    function getPost(){
        function show($status,$msg,$data=[],$count){
            $result = [
                'status' => $status,
                'msg' => $msg,
                'data' => $data,
                'count'=>$count,
            ];
            exit(json_encode($result));
        }
        $post=M('post');
        $reply=M('reply');
        $id=I('get.id');
        $count=$post->where('post.id="'.$id.'"')->find();
        $rel=$reply->where('reply.pid="'.$id.'"')->select();
        $data=[ $count,$rel];
        return show('success','成功',$data);

    }
}

