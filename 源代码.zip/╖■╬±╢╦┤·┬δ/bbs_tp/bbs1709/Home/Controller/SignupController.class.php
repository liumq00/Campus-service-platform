<?php
namespace Home\Controller;
use Think\Controller;
header("Access-Control-Allow-Origin:*");
header("Access-Control-Allow-Methods:GET, POST, OPTIONS, DELETE");
header("Access-Control-Allow-Headers:DNT,X-Mx-ReqToken,Keep-Alive,User-Agent,X-Requested-With,If-Modified-Since,Cache-Control,Content-Type, Accept-Language, Origin, Accept-Encoding");

class SignupController extends Controller {
    public function index(){
        if(isset($_SESSION['res'])){
            $this->redirect('Index/index');    //重定向
        }else{
            $this->display('Signup/index');
        }
    }


    public function check(){
        //返还的json数据
        function show($status,$msg,$data=[]){
            $result = [
                'status' => $status,
                'msg' => $msg,
                'data' => $data
            ];
            exit(json_encode($result));
        }
        $userName = I('get.userName');
        $nickName = I('get.nickname');

        //实例化user表
        $user = M('user');

        //判断用户名是否已存在
        if($user->where('userName="'.$userName.'"')->select()){
            return show('1','抱歉，用户名已存在！');
        }

        //实例化 userdetail 用户详情表
        $ud = M('userdetail');

        //判断昵称是否已存在
        if($ud->where('nickName="'.$nickName.'"')->select()){
            return show('2','抱歉，昵称已存在！');
        }else{
            return show('3','可以创建用户');
        }


    }

    function savaPic(){
        //返还的json数据
        function show($status,$msg,$data=[]){
            $result = [
                'status' => $status,
                'msg' => $msg,
                'data' => $data
            ];
            exit(json_encode($result));
        }
        //======================图片上传=======================================
        //1. 实例化上传类
        $upload = new \Think\Upload();

        //2. 设置参数
        $upload->maxSize = 3145728 ;// 设置附件上传大小
        $upload->exts = array('jpg', 'gif', 'png', 'jpeg');// 设置附件上传类型
        $upload->rootPath = './Public/Photos/'; // 设置附件上传根目录
        $upload->autoSub = false;

        //3. 执行上传
        $info = $upload->upload();



        //4. 判断结果
        if(!$info) {
            // 上传错误提示错误信息

            return show('defeat',$upload->getError(),$info);
        }

        //======================图片缩放=======================================
        $picName=$info['file']['savename'];

        $image = new \Think\Image();

        $image->open($upload->rootPath.$picName);

        $image->thumb(200, 200)->save($upload->rootPath.'l_'.$picName);
        $image->thumb(100, 100)->save($upload->rootPath.'m_'.$picName);
        $image->thumb(50, 50)->save($upload->rootPath.'s_'.$picName);

        return show('successs',$picName);

    }
    public function doSignup()
    {
        //返还的json数据
        function show($status,$msg,$data=[]){
            $result = [
                'status' => $status,
                'msg' => $msg,
                'data' => $data
            ];
            exit(json_encode($result));
        }
        //获取用户数据
        $userName = I('post.userName');
        $nickName = I('post.nickName');
        $password = I('post.password');

        //实例化user表
        $user = M('user');

        //判断用户名是否已存在
        if($user->where('userName="'.$userName.'"')->select()){
            return show('fail','抱歉，用户名已存在！',[ $userName,$nickName,  $password]);
        }

        //所有判断都通过之后，可以将用户的信息添加到user表
        $_POST['password'] = md5($_POST['password']);

        //执行添加
        $id = $user->add($_POST);

        //判断是否添加成功
        if($id){

            //定义存储uid和email的数组
            $data = array();
            $data['uid'] = $id;

            if(isset($_POST['nickName'])){
                $data['nickName']=$_POST['nickName'];
            }
            if(isset($_POST['photo'])){
                $data['photo']=$_POST['photo'];
            }
            //实例化 userdetail 用户详情表
            $ud = M('userdetail');
            //执行userdetail信息的添加
            $id2 = $ud->add($data);

            //判断userdetail信息是否添加成功
            if($id2){
                return show('success','恭喜，注册成功！',[$_POST]);
               // $this->success('恭喜，注册成功！',U('Home/Index/index'),3);
            }else{
                return show('fail','抱歉，注册失败！',[ $_POST]);
                //$this->error('抱歉，注册失败！');
            }
        }
    }
}