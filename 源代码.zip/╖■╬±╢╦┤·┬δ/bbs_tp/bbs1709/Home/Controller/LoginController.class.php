<?php
namespace Home\Controller;
use Think\Controller;

header("Access-Control-Allow-Origin:*");
header("Access-Control-Allow-Methods:GET, POST, OPTIONS, DELETE");
header("Access-Control-Allow-Headers:DNT,X-Mx-ReqToken,Keep-Alive,User-Agent,X-Requested-With,If-Modified-Since,Cache-Control,Content-Type, Accept-Language, Origin, Accept-Encoding");

class LoginController extends Controller {

//获取验证码
    public function getcode()
    {
        $config =    array(
            'fontSize'    =>    18,    // 验证码字体大小
            'length'      =>    3,                            // 验证码位数
            'useNoise'    =>    false,                        // 关闭验证码杂点
            'imageW'   =>100,
            'imageH'   =>30
        );
        $Verify =     new \Think\Verify($config);
        $Verify->codeSet = '0123456789';
        $Verify->entry();
    }
    public function index(){

        if(isset($_SESSION['res'])){
            $this->redirect('Index/index');    //重定向
        }else{
            $this->display('Login/index');
        }
    }

    public function doLogin()
    {
        //返还的json数据
        function show($status,$msg,$data=[]){
            $result = [
                'status' => $status,
                'msg' => $msg,
                'data' => $data
            ];
            exit(json_encode($result));
        }
        //1. 获取登录信息

        $userName=$_GET['username'];
        $password=$_GET['password'];
        $code= $_GET['code'];



//        //实例化验证码类，并验证
//        $verify = new \Think\Verify();
//        $res1 = $verify->check($code);
//        echo $code;
//        echo $res1;
//        if(!$res1){
////            $this->error('登陆失败，验证码错误！');
////            die;
//
//            return show('1','验证码错误');
//
//        }


//        //2. 判断是否为空
//        if($userName==null || $password==null){
//            $this->error('用户名或密码为空！');
//            die;
//        }

        //3. 验证用户名和密码
        $user=M('user');
        $res=$user->where('userName="'.$userName.'" && password="'.md5($password).'"')->find();


        //4. 记录登陆时间
        $lastLogin=date('Y/m/d H:i:s');
        $user->where('id = '.$res['id'])->save();

        //4. 判断结果，并传数据到$_SESSION
        if($res){
            $ud=M('userdetail');
            $photo = $ud->field('photo')->where('uid = '.$res['id'])->find();
            $nickname = $ud->field('nickname')->where('uid = '.$res['id'])->find();

            $_SESSION['res']=$res;
            $_SESSION['photo']=$photo['photo'];

//            $this->success('登陆成功',$_SERVER['HTTP_REFERER'],3);

            return show('3','登陆成功',[$res,$photo,  $nickname]);
        }else{
//            $this->error('用户名或密码错误！');
            return show('2','用户名或密码错误');
        }
    }

    public function doLogout()
    {
        //1. 销毁session信息
        unset($_SESSION['res']);
        unset($_SESSION['photo']);

        //2. 销毁session文件
//        session_destroy();

        //3. 销毁cookie信息
//        setcookie('SESSID','',time()-1,'/');

        //4. 跳转
        $this->success('退出成功',$_SERVER['HTTP_REFERER'],3);

    }
}